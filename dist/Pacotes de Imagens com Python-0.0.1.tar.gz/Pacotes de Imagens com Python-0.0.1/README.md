# image_processing

Description.
The package package is used to:
Processing - Histrogram matching - Structural similarity - Resize image
Utils: - Read image - Save image - plot image - plot resul - plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package

```bash
pip install Pacotes de Imagens com Python
```

## Usage

```python
from Pacotes de Imagens com Python import file_name
file_name.my_function()
```

## Author

Cleison

## License

[MIT](https://choosealicense.com/licenses/mit/)
